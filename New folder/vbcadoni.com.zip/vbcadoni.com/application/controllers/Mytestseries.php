<?php
	class Mytestseries extends CI_Controller
	{
		
	}
?>